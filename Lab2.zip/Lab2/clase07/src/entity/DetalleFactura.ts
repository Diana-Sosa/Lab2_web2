import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { IsNotEmpty, IsNumber, IsPositive } from "class-validator";
 

@Entity()
export class DetalleFactura {

    @PrimaryGeneratedColumn()
    id: number;

    @ManyToOne(() => Factura, factura => factura.detalles)
    factura: Factura;

    @Column()
    @IsNotEmpty({ message: 'Debe indicar la cantidad.' })
    @IsNumber({}, { message: 'La cantidad debe ser un número.' })
    @IsPositive({ message: 'La cantidad debe ser positiva.' })
    cantidad: number;

    @Column()
    @IsNotEmpty({ message: 'Debe indicar el código del producto.' })
    codigoProducto: string; // Asumiendo que el código del producto es un string

}
